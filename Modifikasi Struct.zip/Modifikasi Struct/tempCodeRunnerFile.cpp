out << "Nama Paket : " << stack[i].nama_paket << endl;
            cout << "Berat : " << stack[i].berat << endl;
            cout << "Kota : " << stack[i].kota << endl;